package com.github.ftusita.ms_proposta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
public class MsPropostaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsPropostaApplication.class, args);
	}

}
