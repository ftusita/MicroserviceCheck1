package com.github.ftusita.ms_proposta.service;

import com.github.ftusita.ms_proposta.dto.UserDTO;
import com.github.ftusita.ms_proposta.model.User;
import com.github.ftusita.ms_proposta.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> findAll() {
        return userRepository.findAll();
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public User insert(UserDTO userDTO) {
        User user = new User();
        user.setNome(userDTO.getNome());
        user.setSobrenome(userDTO.getSobrenome());
        user.setCpf(userDTO.getCpf());
        user.setTelefone(userDTO.getTelefone());
        user.setRenda(userDTO.getRenda());
        return userRepository.save(user);
    }

    public User update(Long id, UserDTO userDTO) {
        User user = userRepository.getReferenceById(id);
        user.setNome(userDTO.getNome());
        user.setSobrenome(userDTO.getSobrenome());
        user.setCpf(userDTO.getCpf());
        user.setTelefone(userDTO.getTelefone());
        user.setRenda(userDTO.getRenda());
        return userRepository.save(user);
    }

    public void delete(Long id) {
        userRepository.deleteById(id);
    }
}