import com.github.ftusita.ms_proposta.dto.PropostaDTO;
import com.github.ftusita.ms_proposta.model.Proposta;
import com.github.ftusita.ms_proposta.service.PropostaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/propostas")
public class PropostaController {

    @Autowired
    private PropostaService propostaService;

    @PostMapping
    public ResponseEntity<Proposta> insert(@RequestBody PropostaDTO propostaDTO) {
        return ResponseEntity.ok(propostaService.insert(propostaDTO));
    }
}