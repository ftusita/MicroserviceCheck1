package com.github.ftusita.ms_proposta.service;

import com.github.ftusita.ms_proposta.dto.PropostaDTO;
import com.github.ftusita.ms_proposta.model.Proposta;
import com.github.ftusita.ms_proposta.model.User;
import com.github.ftusita.ms_proposta.repository.PropostaRepository;
import com.github.ftusita.ms_proposta.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PropostaService {

    @Autowired
    private PropostaRepository propostaRepository;

    @Autowired
    private UserRepository userRepository;

    public Proposta insert(PropostaDTO propostaDTO) {
        User user = userRepository.getReferenceById(propostaDTO.getUserId());
        Proposta proposta = new Proposta();
        proposta.setValorSolicitado(propostaDTO.getValorSolicitado());
        proposta.setPrazoMeses(propostaDTO.getPrazoMeses());
        proposta.setAprovado(false);
        proposta.setUser(user);
        return propostaRepository.save(proposta);
    }
}
