-- Inserção de usuários
INSERT INTO app_user (nome, sobrenome, cpf, telefone, renda) VALUES ('Felipe', 'Tusita', '12345678912', '11983113299', 2000.00);
INSERT INTO app_user (nome, sobrenome, cpf, telefone, renda) VALUES ('Ana', 'Silva', '98765432100', '11981234567', 3500.00);
INSERT INTO app_user (nome, sobrenome, cpf, telefone, renda) VALUES ('Carlos', 'Santos', '11122233344', '11987654321', 1500.00);

-- Inserção de propostas associadas aos usuários
INSERT INTO proposta (prazo_meses, aprovado, valor_solicitado, user_id) VALUES (24, false, 5000.00, 1);
INSERT INTO proposta (prazo_meses, aprovado, valor_solicitado, user_id) VALUES (36, false, 10000.00, 1);
INSERT INTO proposta (prazo_meses, aprovado, valor_solicitado, user_id) VALUES (12, false, 3000.00, 2);
INSERT INTO proposta (prazo_meses, aprovado, valor_solicitado, user_id) VALUES (18, false, 4500.00, 2);
INSERT INTO proposta (prazo_meses, aprovado, valor_solicitado, user_id) VALUES (24, false, 6000.00, 3);
INSERT INTO proposta (prazo_meses, aprovado, valor_solicitado, user_id) VALUES (36, false, 12000.00, 3);
